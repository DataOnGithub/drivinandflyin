// enter your API key here
tomtom.apiKey = "";

if (!tomtom.apiKey)
	alert("Please edit apikey.js and enter your API key. The examples will not function until an API key has been entered.");